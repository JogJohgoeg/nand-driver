// web2tape 插件 · 后台：替 web2tape 页面读网页。代码 MIT。
// 页面经 relay.js 连进来（端口名 web2tape），发 { type: 'grab', req }；这里回 progress / file（每个文件一条，base64）/ done / error。
// 读网页用插件的 fetch（有全部网址的读取权限，不受跨站限制；不带你的登录状态，免得把私人页面存上链）；
// 靠脚本画出来的页面开一个后台标签页，等它自己跑完再取画好的 HTML。
import { grab } from './core.js';

async function fetchUrl(url, limit) {
  const r = await fetch(url, { credentials: 'omit', redirect: 'follow', signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error(`HTTP Error ${r.status}: ${r.statusText}`);
  const len = +r.headers.get('content-length');
  if (len > limit) throw new Error(`超过 ${limit} 字节`);
  const bytes = new Uint8Array(await r.arrayBuffer());
  if (bytes.length > limit) throw new Error(`超过 ${limit} 字节`);
  return { url: r.url, type: r.headers.get('content-type') || '', bytes };
}

async function render(url) {
  const tab = await chrome.tabs.create({ url, active: false });
  try {
    await new Promise((resolve, reject) => {
      const t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(on); reject(new Error('timeout')); }, 20000);
      function on(id, info) { if (id === tab.id && info.status === 'complete') { clearTimeout(t); chrome.tabs.onUpdated.removeListener(on); resolve(); } }
      chrome.tabs.onUpdated.addListener(on);
    });
    await new Promise((r) => setTimeout(r, 2500));          // 等页面自己的脚本把内容画出来
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id },
      func: () => (document.doctype ? '<!doctype html>\n' : '') + document.documentElement.outerHTML });
    return res && typeof res.result === 'string' && /<\/html>/i.test(res.result) ? res.result : null;
  } finally {
    chrome.tabs.remove(tab.id).catch(() => {});
  }
}

const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'web2tape') return;
  let gone = false;
  port.onDisconnect.addListener(() => { gone = true; });
  const post = (m) => { if (!gone) port.postMessage(m); };
  port.onMessage.addListener(async (msg) => {
    if (msg.type === 'ping') return post({ type: 'pong', version: chrome.runtime.getManifest().version });
    if (msg.type !== 'grab') return;
    try {
      const r = await grab(msg.req, { fetchUrl, render, say: (text) => post({ type: 'progress', text }) });
      for (const f of r.files) post({ type: 'file', path: f.path, contentType: f.contentType, b64: b64(f.bytes) });
      const { files, ...meta } = r;
      post({ type: 'done', ...meta });
    } catch (e) {
      post({ type: 'error', message: e.message || String(e) });
    }
  });
});

// 工具栏按钮：在任何网站上点一下，打开 web2tape 并自动预览当前这一页所在的网站
const PAGES = ['http://127.0.0.1:8790/', 'https://nand.aihashrate.stream/web2tape/'];   // 本机开着 server.py 就用本机，否则用线上
chrome.action.onClicked.addListener(async (tab) => {
  let page = PAGES[1];
  try { if ((await (await fetch(PAGES[0] + 'health', { signal: AbortSignal.timeout(800) })).json()).web2tape) page = PAGES[0]; } catch {}
  const u = /^https?:/.test(tab.url || '') ? tab.url : '';
  chrome.tabs.create({ url: page + (u ? '?auto=1&url=' + encodeURIComponent(u) : ''), index: tab.index + 1 });
});
