// web2tape 插件 · 读网页的核心（与 ../server.py 的 grab 同一套规则，逐条对照移植）。代码 MIT。
// 浏览器插件的后台和 Node（≥ 20，测试用）通用：只用 fetch、TextDecoder、crypto.subtle。
// 用法：await grab({ url, whole, maxPages, maxDepth, keepScripts, maxBytes }, { fetchUrl, render, say })
//   fetchUrl(url) → { url: 最终网址, type: Content-Type, bytes: Uint8Array }（插件里就是 fetch，有 host 权限不受跨站限制）
//   render(url)   → 渲染后的 HTML 字符串或 null（插件里开一个后台标签页，等网站自己的脚本跑完再取 DOM）
//   say(text)     → 进度
// 返回 { url, title, page, pages, warnings, files: [{ path, contentType, bytes }] }

const PER_FILE = 2_000_000;           // 单个资源超过这个就不存，留原网址（图片、字体、样式的 https 外链网关允许）
const PAGE_LIMIT = 5_000_000;
const te = new TextEncoder();

const EXT = { 'text/css': '.css', 'image/png': '.png', 'image/jpeg': '.jpg', 'image/gif': '.gif', 'image/webp': '.webp', 'image/svg+xml': '.svg',
  'image/x-icon': '.ico', 'image/vnd.microsoft.icon': '.ico', 'image/avif': '.avif', 'font/woff2': '.woff2', 'font/woff': '.woff',
  'font/ttf': '.ttf', 'font/otf': '.otf', 'application/font-woff2': '.woff2', 'application/font-woff': '.woff',
  'text/javascript': '.js', 'application/javascript': '.js', 'application/x-javascript': '.js' };
export const TYPE = { '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.avif': 'image/avif', '.woff2': 'font/woff2',
  '.woff': 'font/woff', '.ttf': 'font/ttf', '.otf': 'font/otf', '.js': 'text/javascript; charset=utf-8', '.html': 'text/html; charset=utf-8' };
const PAGE_EXT = new Set(['', '.html', '.htm', '.shtml', '.php', '.asp', '.aspx', '.jsp']);
const DROP_REL = new Set(['preload', 'modulepreload', 'prefetch', 'dns-prefetch', 'preconnect', 'manifest', 'canonical', 'alternate', 'amphtml']);

const hexOf = (buf) => Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('');
export const sha256hex = async (bytes) => hexOf(await crypto.subtle.digest('SHA-256', bytes));
const sha1hex = async (s) => hexOf(await crypto.subtle.digest('SHA-1', te.encode(s)));
const suffix = (path) => { const m = /\.[^./]*$/.exec(path.split('/').pop() || ''); return m ? m[0].toLowerCase() : ''; };
const abs = (base, u) => { try { return new URL(u, base).href; } catch { return null; } };
const host = (u) => { try { return new URL(u).hostname.toLowerCase(); } catch { return ''; } };
const unescapeHtml = (s) => s.replace(/&(#x?[0-9a-f]+|amp|lt|gt|quot|apos|#39|nbsp);/gi, (m, e) => {
  const k = e.toLowerCase();
  if (k[0] === '#') { const n = k[1] === 'x' ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10); try { return String.fromCodePoint(n); } catch { return m; } }
  return { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' }[k] ?? m;
});
const attrEsc = (s) => s.replace(/"/g, '&quot;');

export const bare = (h) => { h = (h || '').toLowerCase(); return h.startsWith('www.') ? h.slice(4) : h; };   // example.com 和 www.example.com 算同一个网站

/** 站内页面的归一化网址：去掉 #片段，/index.html 与 /、末尾的 / 不区分。带 ?查询 的不算独立页面（返回 null）。 */
export function pageKey(u) {
  let s; try { s = new URL(u); } catch { return null; }
  if (!/^https?:$/.test(s.protocol) || s.search) return null;
  let path = (s.pathname || '/').replace(/\/index\.html?$/i, '/');
  if (path !== '/' && path.endsWith('/')) path = path.slice(0, -1);
  return (bare(s.hostname) + decodeURI(path)).toLowerCase();
}

/** 网址路径 → 容器里的目录（相对站点根）：/a/b.html → a/b.html/，/ → 空。改过名的段（中文、空格等）加 6 位哈希，免得撞名 */
export async function pageDirOf(u) {
  const path = new URL(u).pathname.replace(/\/index\.html?$/i, '/');
  let out = '';
  for (const raw of path.split('/').filter(Boolean)) {
    let x; try { x = decodeURIComponent(raw); } catch { x = raw; }
    const y = x.replace(/[^A-Za-z0-9._~-]+/g, '-').replace(/^[.-]+|[.-]+$/g, '').slice(0, 60);
    out += (y === x ? y : (y ? y + '-' : '') + (await sha1hex(x)).slice(0, 6)) + '/';
  }
  return out;
}

export function decodeHtml(type, bytes) {
  const head = new TextDecoder('latin1').decode(bytes.subarray(0, 4096));
  const m = /charset=([\w-]+)/i.exec(type || '') || /<meta[^>]+charset=["']?([\w-]+)/i.exec(head);
  try { return new TextDecoder(m ? m[1] : 'utf-8').decode(bytes); } catch { return new TextDecoder('utf-8').decode(bytes); }
}

export function visibleText(html) {
  const t = html.replace(/<(script|style|noscript|template)\b[\s\S]*?<\/\1\s*>/gi, ' ');
  return unescapeHtml(t.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
}

class Grab {
  constructor(maxBytes, fetchUrl) {
    this.maxBytes = maxBytes; this.fetchUrl = fetchUrl;
    this.used = 0;
    this.assets = new Map();   // 原网址 → 文件名（_assets/ 下）或 null
    this.files = new Map();    // 文件名 → { bytes, type }
    this.cache = new Map();    // 原网址 → Promise<结果或 Error>，prefetch 并发预取
    this.warn = [];
  }
  get(u) {
    if (!this.cache.has(u)) this.cache.set(u, this.fetchUrl(u, PER_FILE).catch((e) => e));
    return this.cache.get(u);
  }
  async prefetch(urls) {           // 一次最多 12 个并发
    const todo = [...new Set(urls)].filter((u) => /^https?:\/\//.test(u) && !this.cache.has(u) && !this.assets.has(u));
    for (let i = 0; i < todo.length; i += 12) await Promise.all(todo.slice(i, i + 12).map((u) => this.get(u)));
  }
  /** 存一个资源进 _assets/，返回文件名；放不下或失败返回 null（调用方保留原网址） */
  async asset(absurl, kind) {
    if (!absurl || !/^https?:\/\//.test(absurl)) return null;
    if (this.assets.has(absurl)) return this.assets.get(absurl);
    this.assets.set(absurl, null);
    const r = await this.get(absurl);
    this.cache.delete(absurl);
    if (r instanceof Error) { this.warn.push(`没取到 ${absurl}：${r.message}`); return null; }
    const base = (r.type || '').split(';')[0].trim().toLowerCase();
    let ext = suffix(new URL(r.url).pathname);
    ext = TYPE[ext] ? ext : (EXT[base] || '');
    let data = r.bytes;
    if (kind === 'css' || ext === '.css') {
      ext = '.css';
      data = te.encode(await this.css(new TextDecoder().decode(r.bytes), r.url, true));
    }
    if (this.used + data.length > this.maxBytes) { this.warn.push(`超出总大小上限，留外链：${absurl}（${data.length} 字节）`); return null; }
    const name = (await sha256hex(data)).slice(0, 16) + ext;
    if (!this.files.has(name)) { this.files.set(name, { bytes: data, type: TYPE[ext] || r.type || 'application/octet-stream' }); this.used += data.length; }
    this.assets.set(absurl, name);
    return name;
  }
  async css(text, base, insideAssets, prefix = '_assets/') {
    const pre = insideAssets ? '' : prefix;
    text = text.replace(/@import\s+(["'][^"']+["'])/gi, '@import url($1)');
    return replaceAsync(text, /(url\()\s*([^)]*)\)/gi, async (m0, g1, g2, off) => {
      const raw = g2.trim().replace(/^["']|["']$/g, '');
      if (!raw || raw.startsWith('data:') || raw.startsWith('#')) return m0;
      const u = abs(base, unescapeHtml(raw));
      if (!u) return m0;
      const isImport = text.slice(Math.max(0, off - 8), off).toLowerCase().endsWith('@import ');
      const n = await this.asset(u, isImport ? 'css' : 'bin');      // 逐个等：同一网址第二次进来时直接用第一次的结果
      return `${g1}"${n ? pre + n : u}")`;
    });
  }
}

const ATTR = /(\s)([\w:-]+)(\s*=\s*)("[^"]*"|'[^']*'|[^\s"'>]+)/g;
const TAG = /<([a-zA-Z][\w-]*)\b((?:[^>"']|"[^"]*"|'[^']*')*?)(\/?)>/g;

/** 异步版 String.replace：先收集所有匹配并逐个算出替换，再拼回去 */
async function replaceAsync(str, re, fn) {
  const parts = []; let last = 0;
  for (const m of str.matchAll(re)) {
    parts.push(str.slice(last, m.index), await fn(...m, m.index));
    last = m.index + m[0].length;
  }
  parts.push(str.slice(last));
  return parts.join('');
}

function baseOf(final, html) {
  const m = /<base\s[^>]*href=["']([^"']+)/i.exec(html);
  return m ? abs(final, unescapeHtml(m[1])) || final : final;
}

function linksOf(html, base) {
  const out = [];
  for (const m of html.matchAll(/<(?:a|area)\b[^>]*?\shref\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi)) {
    const v = unescapeHtml(m[1].replace(/^["']|["']$/g, ''));
    if (!/^(#|javascript:|mailto:|tel:|data:)/i.test(v)) { const u = abs(base, v); if (u) out.push(u.split('#')[0]); }
  }
  return out;
}

/** 把一页改写成静态快照：资源进 g（_assets/），站内已抓的页面链接由 link(绝对网址) 给出相对路径 */
async function snapshot(final, html, keep, g, prefix, link) {
  const base = baseOf(final, html);
  html = html.replace(/<base\s[^>]*>/gi, '')
    .replace(/<meta[^>]+http-equiv=["']?(content-security-policy|refresh)[^>]*>/gi, '')
    .replace(/<meta[^>]+charset[^>]*>/gi, '');
  if (!keep) {
    html = html.replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, '')
      .replace(/<noscript\b[^>]*>([\s\S]*?)<\/noscript\s*>/gi, '$1');
  }
  // 先并发预取这页用到的资源，改写时直接从缓存拿
  const refs = [];
  for (const m of html.matchAll(/<(?:img|source|video|audio|input|track|embed)\b[^>]*?\s(?:src|poster|data-src|data-original|data-lazy-src)\s*=\s*["']?([^"'\s>]+)/gi)) refs.push(m[1]);
  for (const t of html.match(/<link\b[^>]*>/gi) || []) {
    if (/rel\s*=\s*["']?[^"'>]*(pre|dns|manifest|canonical|alternate)/i.test(t)) continue;
    for (const m of t.matchAll(/\shref\s*=\s*["']?([^"'\s>]+)/gi)) refs.push(m[1]);
  }
  for (const m of html.matchAll(/\s(?:srcset|imagesrcset)\s*=\s*["']([^"']+)["']/gi))
    for (const c of m[1].split(',')) { const b = c.trim().split(/\s+/)[0]; if (b) refs.push(b); }
  for (const m of html.matchAll(/url\(\s*["']?([^"')]+)/gi)) refs.push(m[1]);
  await g.prefetch(refs.filter((r) => !/^(data:|#)/.test(r)).map((r) => abs(base, unescapeHtml(r))).filter(Boolean));

  html = await replaceAsync(html, /<style\b([^>]*)>([\s\S]*?)<\/style\s*>/gi, async (m0, a, body) => `<style${a}>${await g.css(body, base, false, prefix)}</style>`);

  html = await replaceAsync(html, TAG, async (m0, tagName, attrs, close) => {
    const name = tagName.toLowerCase();
    if (name === 'link') {
      const rel = new Set(((/rel\s*=\s*["']?([^"'>]+)/i.exec(attrs) || [])[1] || '').toLowerCase().split(/\s+/));
      if ([...rel].some((r) => DROP_REL.has(r))) return '';
    }
    const newAttrs = await replaceAsync(attrs, ATTR, async (am, sp, kRaw, eq, v) => {
      const k = kRaw.toLowerCase();
      const q = v[0] === '"' || v[0] === "'" ? v[0] : '"';
      const val = unescapeHtml(v.replace(/^["']|["']$/g, ''));
      if (['integrity', 'crossorigin', 'nonce'].includes(k) || (k.startsWith('on') && !keep)) return '';
      if (k === 'style') {
        const c = await g.css(val, base, false, prefix);
        return `${sp}${kRaw}=${q}${c.split(q).join(q === '"' ? '&quot;' : '&#39;')}${q}`;
      }
      let nv = null;
      if ((k === 'href' || k === 'action') && ['a', 'area', 'form'].includes(name)) {
        if (!/^(#|javascript:|mailto:|tel:)/i.test(val)) { const u = abs(base, val); if (u) nv = (k === 'href' ? link(u) : null) || u; }
      } else if (k === 'href' && name === 'link') {
        const u = abs(base, val); const n = await g.asset(u, /stylesheet/i.test(attrs) ? 'css' : 'bin');
        nv = n ? prefix + n : u;
      } else if ((['src', 'poster'].includes(k) && ['img', 'source', 'video', 'audio', 'input', 'track', 'embed'].includes(name)) || (k === 'src' && name === 'script' && keep)) {
        if (!val.startsWith('data:')) { const u = abs(base, val); const n = await g.asset(u, 'bin'); nv = n ? prefix + n : u; }
      } else if (k === 'srcset' || k === 'imagesrcset') {
        const parts = [];
        for (const c of val.split(',')) {
          const bits = c.trim().split(/\s+/);
          if (bits[0] && !bits[0].startsWith('data:')) { const u = abs(base, bits[0]); const n = await g.asset(u, 'bin'); bits[0] = n ? prefix + n : (u || bits[0]); }
          parts.push(bits.join(' '));
        }
        nv = parts.join(', ');
      } else if (['data-src', 'data-original', 'data-lazy-src'].includes(k) && name === 'img') {
        const u = abs(base, val); const n = await g.asset(u, 'bin');
        return ` src="${attrEsc(n ? prefix + n : (u || val))}"`;
      }
      if (nv == null) return am;
      return `${sp}${kRaw}="${attrEsc(nv)}"`;
    });
    return `<${tagName}${newAttrs}${close}>`;
  });

  const stamp = new Date().toISOString().slice(0, 16).replace('T', ' ') + ' UTC';
  const esc = final.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  const head = `<meta charset="utf-8">\n<!-- web2tape 链上快照：${esc} @ ${stamp} -->\n<meta name="tape-source" content="${esc}">\n`;
  const badge = `<a href="${esc}" style="position:fixed;right:10px;bottom:10px;z-index:2147483647;font:12px/1.4 system-ui,sans-serif;`
    + `background:#006B35;color:#fff;padding:4px 9px;border-radius:12px;text-decoration:none;opacity:.85">链上快照 · ${stamp.slice(0, 10)} · 原网页 ↗</a>`;
  html = /<head\b[^>]*>/i.test(html) ? html.replace(/(<head\b[^>]*>)/i, (m) => m + '\n' + head) : head + html;
  html = /<\/body\s*>/i.test(html) ? html.replace(/(<\/body\s*>)/i, (m) => badge + m) : html + badge;
  if (!/^\s*<!doctype/i.test(html)) html = '<!doctype html>\n' + html;
  const title = unescapeHtml(((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html) || [])[1] || '').trim()).slice(0, 120);
  return { title, bytes: te.encode(html) };
}

async function loadPage(url, keep, render, env) {
  const r = await env.fetchUrl(url, PAGE_LIMIT);
  if (r.type && !/html|xml/i.test(r.type)) throw new Error(`不是网页（${r.type.split(';')[0]}）`);
  let html = decodeHtml(r.type, r.bytes);
  // 服务器给的 HTML 里已经有正文就直接用；正文几乎空、靠脚本画的页面才交给浏览器渲染
  if (render.on && env.render && !keep && visibleText(html).length < 100 && /<script\b/i.test(html)) {
    const h = await env.render(r.url).catch(() => null);
    if (h) html = h; else render.on = false;         // 渲染一次没成功，这次就不再试
  }
  return { final: r.url, html };
}

export async function grab(req, env) {
  const say = env.say || (() => {});
  let url = (req.url || '').trim();
  if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
  const keep = !!req.keepScripts, render = { on: req.render !== false };
  const whole = req.whole !== false;
  const maxPages = whole ? Math.max(1, Math.min(+req.maxPages || 30, 300)) : 1;
  const maxDepth = +req.maxDepth || 4;
  const maxBytes = +req.maxBytes || 8_000_000;
  let site = bare(host(url));
  const g = new Grab(maxBytes, env.fetchUrl);

  // 1. 抓页面、找链接（页面 HTML 合计最多占总上限的一半，剩下留给图片、样式、字体）
  const pages = [], seen = new Set(), queue = [[url, 0]];
  let htmlBytes = 0;
  while (queue.length && pages.length < maxPages) {
    const [u, d] = queue.shift();
    const k = pageKey(u);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    let p;
    try {
      say(`抓页面 ${pages.length + 1}/${maxPages}：${u}`);
      p = await loadPage(u, keep, render, env);
    } catch (e) {
      if (!pages.length) throw e;
      g.warn.push(`页面没取到 ${u}：${e.message}`);
      continue;
    }
    if (!pages.length) site = bare(host(p.final));     // 起始网址跳到了别的域名：以跳到的为准
    const fk = pageKey(p.final);
    if (bare(host(p.final)) !== site || (fk !== k && seen.has(fk) && pages.length)) continue;
    seen.add(fk);
    htmlBytes += te.encode(p.html).length;
    pages.push({ url: p.final, keys: [k, fk], html: p.html, dir: await pageDirOf(p.final) });
    if (htmlBytes > maxBytes / 2) { g.warn.push(`页面合计已超过上限的一半，停在第 ${pages.length} 页`); break; }
    if (d < maxDepth) {
      for (const v of linksOf(p.html, baseOf(p.final, p.html))) {
        const s = new URL(v);
        if (bare(s.hostname) === site && PAGE_EXT.has(suffix(s.pathname)) && !seen.has(pageKey(v))) queue.push([v, d + 1]);
      }
    }
  }
  if (!pages.length) throw new Error('没读到任何网页');
  if (queue.length && pages.length >= maxPages) g.warn.push(`到了最多 ${maxPages} 页，还有没抓的站内链接（点了会回原网站）`);
  const root = `web/${host(pages[0].url).replace(/[^a-z0-9.-]/g, '-')}/`;

  // 2. 改写：站内已抓页面互相用相对路径，其余链接回原网站
  const where = new Map();
  for (const p of pages) for (const k of p.keys) if (k && !where.has(k)) where.set(k, p.dir);
  const files = [];
  for (const [i, p] of pages.entries()) {
    say(`改写 ${i + 1}/${pages.length}：${p.url}（连同图片、样式、字体）`);
    const cur = p.dir, depth = cur.split('/').length - 1;
    const link = (u) => {
      const [noFrag, frag] = u.split('#');
      const k = pageKey(noFrag);
      if (!where.has(k)) return null;
      return relPath(where.get(k) + 'index.html', cur) + (frag != null ? '#' + frag : '');
    };
    const { title, bytes } = await snapshot(p.url, p.html, keep, g, '../'.repeat(depth) + '_assets/', link);
    p.title = title;
    files.push({ path: root + cur + 'index.html', contentType: TYPE['.html'], bytes });
  }
  for (const [n, f] of [...g.files.entries()].sort()) files.push({ path: root + '_assets/' + n, contentType: f.type, bytes: f.bytes });
  return { url: pages[0].url, title: pages[0].title, page: root + pages[0].dir, pages: pages.length, warnings: g.warn.slice(0, 80), files };
}

/** posix relpath(to, fromDir)：两者都相对同一个根，fromDir 以 / 结尾或为空 */
function relPath(to, fromDir) {
  const a = to.split('/'), b = fromDir.split('/').filter(Boolean);
  let i = 0;
  while (i < b.length && i < a.length - 1 && a[i] === b[i]) i++;
  return '../'.repeat(b.length - i) + a.slice(i).join('/');
}
