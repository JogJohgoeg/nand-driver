// web2tape 插件 · 页面与后台之间的传话（只在 manifest 里列出的 web2tape 页面上运行）。代码 MIT。
// 页面 → window.postMessage({ source: 'web2tape-page', id, type, req }) ；插件 → window.postMessage({ source: 'web2tape-ext', id, ... })
(() => {
  const version = chrome.runtime.getManifest().version;
  document.documentElement.dataset.web2tapeExt = version;           // 页面据此知道装了插件
  const reply = (m) => window.postMessage({ source: 'web2tape-ext', ...m }, location.origin);
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || ev.origin !== location.origin) return;
    const m = ev.data;
    if (!m || m.source !== 'web2tape-page') return;
    if (m.type === 'hello') return reply({ id: m.id, type: 'hello', version });
    if (m.type !== 'grab') return;
    const port = chrome.runtime.connect({ name: 'web2tape' });
    port.onMessage.addListener((x) => {
      reply({ id: m.id, ...x });
      if (x.type === 'done' || x.type === 'error') port.disconnect();
    });
    port.onDisconnect.addListener(() => reply({ id: m.id, type: 'closed' }));
    port.postMessage({ type: 'grab', req: m.req });
  });
  reply({ type: 'hello', version });
})();
